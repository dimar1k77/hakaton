#include "hakaton2MainForm.h"


using namespace System;
using namespace System::Windows::Forms;

unsigned int GlobalParTask2 = 0;
[STAThreadAttribute]



int main(array<String^>^ args) {
	Application::SetCompatibleTextRenderingDefault(false);
	Application::EnableVisualStyles();
	hakaton2::hakaton2MainForm mainform;
	Application::Run(% mainform);
}
